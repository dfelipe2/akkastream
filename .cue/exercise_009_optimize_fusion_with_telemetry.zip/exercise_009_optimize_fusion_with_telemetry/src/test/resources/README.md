optimize-fusion-with-telemetry

Please refer to the instructions in the Lightbend Academy.
