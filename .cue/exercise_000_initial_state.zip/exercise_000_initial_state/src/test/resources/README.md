initial-state

Please refer to the instructions in the Lightbend Academy.
