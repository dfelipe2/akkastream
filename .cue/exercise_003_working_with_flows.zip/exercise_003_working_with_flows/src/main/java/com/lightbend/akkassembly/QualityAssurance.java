package com.lightbend.akkassembly;

import akka.NotUsed;
import akka.stream.javadsl.Flow;

class QualityAssurance {
    private final Flow<UnfinishedCar, Car, NotUsed> inspect;

    Flow<UnfinishedCar, Car, NotUsed> getInspect() {
        return inspect;
    }

    QualityAssurance() {
        inspect = Flow.of(UnfinishedCar.class)
            .filter(this::isValid)
            .map(car ->
                new Car(
                    new SerialNumber(),
                    car.getColor().get(),
                    car.getEngine().get(),
                    car.getWheels(),
                    car.getUpgrade()
                )
            );
    }

    private boolean isValid(UnfinishedCar car) {
        return car.getColor().isPresent() &&
          car.getWheels().size() == 4 &&
          car.getEngine().isPresent();
    }
}
