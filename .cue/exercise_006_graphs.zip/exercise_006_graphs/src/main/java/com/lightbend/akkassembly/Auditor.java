package com.lightbend.akkassembly;

import akka.Done;
import akka.NotUsed;
import akka.event.LoggingAdapter;
import akka.stream.Materializer;
import akka.stream.javadsl.Flow;
import akka.stream.javadsl.Sink;
import akka.stream.javadsl.Source;

import java.time.Duration;
import java.util.concurrent.CompletionStage;

class Auditor {
    private final Materializer materializer;

    private final Sink<Car, CompletionStage<Integer>> count;

    Sink<Car, CompletionStage<Integer>> getCount() {
        return count;
    }

    Auditor(Materializer materializer) {
        this.materializer = materializer;
        count = Sink.fold(0, (c, ignore) -> c + 1);
    }

    Sink<Object, CompletionStage<Done>> log(LoggingAdapter loggingAdapter) {
        return Sink.foreach(elem -> loggingAdapter.debug(elem.toString()));
    }

    Flow<Car, Car, NotUsed> sample(Duration sampleSize) {
        return Flow.of(Car.class).takeWithin(sampleSize);
    }

    CompletionStage<Integer> audit(Source<Car, NotUsed> cars, Duration sampleSize) {
        return cars
                .via(sample(sampleSize))
                .runWith(count, materializer);
    }
}
