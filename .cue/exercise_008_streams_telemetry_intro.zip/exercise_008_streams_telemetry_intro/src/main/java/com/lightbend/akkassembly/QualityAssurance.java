package com.lightbend.akkassembly;

import akka.NotUsed;
import akka.japi.function.Function;
import akka.stream.ActorAttributes;
import akka.stream.Supervision;
import akka.stream.javadsl.Flow;

class QualityAssurance {
    static class CarFailedInspection extends IllegalStateException {
        CarFailedInspection(UnfinishedCar car) {
            super("Car Failed Inspection: "+car);
        }
    }

    private final Flow<UnfinishedCar, Car, NotUsed> inspect;

    Flow<UnfinishedCar, Car, NotUsed> getInspect() {
        return inspect;
    }

    QualityAssurance() {
        Function<Throwable, Supervision.Directive> decider = ex -> {
            if(ex instanceof CarFailedInspection)
                return Supervision.resume();
            else
                return Supervision.stop();
        };

        inspect = Flow.of(UnfinishedCar.class)
            .map(car -> {
                if (isValid(car))
                    return new Car(
                            new SerialNumber(),
                            car.getColor().get(),
                            car.getEngine().get(),
                            car.getWheels(),
                            car.getUpgrade()
                    );
                else
                    throw new CarFailedInspection(car);
            }).withAttributes(ActorAttributes.withSupervisionStrategy(decider));
    }

    private boolean isValid(UnfinishedCar car) {
        return car.getColor().isPresent() &&
          car.getWheels().size() == 4 &&
          car.getEngine().isPresent();
    }
}
