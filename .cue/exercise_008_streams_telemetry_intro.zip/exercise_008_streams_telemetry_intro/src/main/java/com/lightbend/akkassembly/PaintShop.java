package com.lightbend.akkassembly;

import akka.NotUsed;
import akka.stream.javadsl.Flow;
import akka.stream.javadsl.Source;

import java.util.Set;

class PaintShop {
    private final Source<Color, NotUsed> colors;
    private final Flow<UnfinishedCar, UnfinishedCar, NotUsed> paint;

    Source<Color, NotUsed> getColors() {
        return colors;
    }

    Flow<UnfinishedCar, UnfinishedCar, NotUsed> getPaint() {
        return paint;
    }

    PaintShop(Set<Color> colorSet) {
        colors = Source.cycle(colorSet::iterator);
        paint = Flow.of(UnfinishedCar.class).zip(colors).map(
            (carAndColor) -> carAndColor.first().paint(carAndColor.second())
        );
    }
}
