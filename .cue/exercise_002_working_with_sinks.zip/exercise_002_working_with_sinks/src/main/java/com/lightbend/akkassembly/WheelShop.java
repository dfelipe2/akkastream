package com.lightbend.akkassembly;

import akka.NotUsed;
import akka.stream.javadsl.Source;

public class WheelShop {
    private final Source<Wheel, NotUsed> wheels;

    Source<Wheel, NotUsed> getWheels() {
        return wheels;
    }

    WheelShop() {
        wheels = Source.repeat(new Wheel());
    }
}
