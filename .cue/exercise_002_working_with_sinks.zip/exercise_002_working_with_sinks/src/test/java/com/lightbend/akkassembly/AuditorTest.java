package com.lightbend.akkassembly;

import akka.stream.javadsl.Source;
import akka.testkit.EventFilter;
import org.junit.Test;

import java.util.List;
import java.util.Optional;
import java.util.Vector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.Assert.*;

public class AuditorTest extends AkkaSpec {

    private List<Car> generateCars(int quantity) {
        List<Car> cars = new Vector<>();
        for(int i = 0; i < quantity; i++) {
            List<Wheel> wheels = new Vector<>();
            wheels.add(new Wheel());
            wheels.add(new Wheel());
            wheels.add(new Wheel());
            wheels.add(new Wheel());

            Car car = new Car(
                    new SerialNumber(),
                    Color.fromHex("000000"),
                    new Engine(),
                    wheels,
                    Optional.empty()
            );

            cars.add(car);
        }

        return cars;
    }

    @Test
    public void count_shouldReturnZeroIfTheStreamIsEmpty() {
        Auditor auditor = new Auditor();

        int count = Source.<Car>empty()
            .runWith(auditor.getCount(), materializer)
            .toCompletableFuture()
            .join();

        assertEquals(0, count);
    }

    @Test
    public void count_shouldCountElementsInTheStream() {
        Auditor auditor = new Auditor();

        int count = Source.from(generateCars(10))
            .runWith(auditor.getCount(), materializer)
            .toCompletableFuture()
            .join();

        assertEquals(10, count);
    }

    @Test
    public void log_shouldLogNothingIfTheSourceIsEmpty() {
        Auditor auditor = new Auditor();

        EventFilter
            .debug(null, null, "", null, 0)
            .intercept(() ->
                Source.empty()
                    .runWith(auditor.log(system.log()), materializer)
                    .toCompletableFuture()
                    .join()
                , system);
    }

    @Test
    public void log_shouldLogAllElementsToTheLoggingAdapter() {
        Auditor auditor = new Auditor();

        EventFilter
            .debug(null, null, "", null, 10)
            .intercept(() ->
                Source.range(1, 10)
                    .map(i -> (Object) i)
                    .runWith(auditor.log(system.log()), materializer)
                    .toCompletableFuture()
                    .join()
                , system);
    }

    @Test
    public void log_shouldLogTheExactElement() {
        Auditor auditor = new Auditor();

        EventFilter
            .debug("Message", null, "", null, 1)
            .intercept(() ->
                Source.single((Object) "Message")
                    .runWith(auditor.log(system.log()), materializer)
                    .toCompletableFuture()
                    .join()
                , system);
    }
}
